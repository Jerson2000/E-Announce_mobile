<?php
include ('../database.php');

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM events";
$result = mysqli_query($conn, $sql);
$str_response = "";

while ($row = mysqli_fetch_assoc($result)) {
    $str_response .= $row['event_name'].'\n';
    $str_response .= $row['date'].'\n';
    $str_response .= $row['time'].'\n';
    $str_response .= $row['description'].'\n\n';
}

print $str_response;
mysqli_close($conn);
?>