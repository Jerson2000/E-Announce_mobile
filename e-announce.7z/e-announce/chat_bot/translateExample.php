<?php
require_once '../vendor/autoload.php';
use Stichoza\GoogleTranslate\GoogleTranslate;

$tr = new GoogleTranslate('en');
echo $tr->translate('Ano ang gagawin?');
echo $tr->getLastDetectedSource();

echo $tr->setSource('en')->setTarget('ceb')->translate('What is the event today?')."<br>";
?>
