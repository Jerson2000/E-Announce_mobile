<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form name="form1" action="" method="post" enctype="multipart/form-data">
        <table>
            <tr>
                <td>Select File</td>
                <td><input type="file" name="f1"></td>
            </tr>
            <tr>
                <td><input type="submit" name="submit1" value="upload"></td>
                <td><input type="submit" name="submit2" value="display"></td>
            </tr>
        </table>
    </form>

<?php
include ('database.php');
if(isset($_POST['submit1']))
{
    $image = getimagesize($_FILES['f1']['tmp_name']);
    print_r($_FILES['f1']['tmp_name']);
    if ($image['mime'] == 'image/jpeg') {
        $input_image = imagecreatefromjpeg($_FILES['f1']['tmp_name']);
    }
    else if ($image['mime'] == 'image/png') {
        $input_image = imagecreatefrompng($_FILES['f1']['tmp_name']);
    }
    else echo 'Please select images only. (JPEG, PNG)';
    if (isset($input_image)) {
        $event_id = "2";
        // Insert new images record and get its id
        mysqli_query($conn, "INSERT INTO images (event_id) VALUES ('$event_id')");
        $id = $conn->insert_id;

        // Save image with 20% quality and use ID as image name
        $output_image_directory = 'image/'.$id.'.jpg';
        $image_quality = 20; // In percent value, 20 is 20%
        imagejpeg($input_image, $output_image_directory, $image_quality);
        print_r($output_image_directory);

        // Updates the recently created with the directory of the created image
        mysqli_query($conn, "UPDATE images SET image='$output_image_directory' WHERE id='$id'");
    }
    
}
if(isset($_POST['submit2']))
{
    $result = mysqli_query($conn, "SELECT image FROM images");
    while ($row = mysqli_fetch_assoc($result))
    {
        $image = file_get_contents($row['image']);
        $image_base64 = base64_encode($image);
        echo '<img src="data:image/jpeg;base64,'.$image_base64.'" width="50%"/>';
    }
}
?>

</body>
</html>