<?php
include ('database.php');

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$event_id = value($_POST['event_id']);
$image = $_POST['image'];

$sql = "INSERT INTO images (event_id) VALUES ($event_id)";
mysqli_query($conn, $sql);
$id = $conn->insert_id;
$file_path = "image/$id.jpg";

$sql = "UPDATE images SET image='$file_path' WHERE id='$id'";
mysqli_query($conn, $sql);
file_put_contents($file_path,base64_decode($image));

echo '[{result: Upload Success}]';
mysqli_close($conn);
?>