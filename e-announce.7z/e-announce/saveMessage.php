<?php
include ('database.php');

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$user_id = value($_POST['user_id']);
$message = value(clean($_POST['message']));
$bot = value(clean($_POST['bot']));

$sql = "INSERT INTO messages(user_id, message, bot) 
        VALUES ($user_id, $message, $bot)";

$result = mysqli_query($conn, $sql);

$array = array();
$sql = strtok($sql, ' ');

if ($sql === 'INSERT' || $sql === 'UPDATE' || $sql === 'DELETE') {
    echo '[{result: Success}]';
}
else if ($sql === 'SELECT') {
    while ($row = mysqli_fetch_assoc($result)) {
        $temp = array();
        foreach ($row as $key => $value) {
            $temp[$key] = $value;
        }
        array_push($array, $temp);
    }
    echo json_encode($array);
}

mysqli_close($conn);
?>