<?php
include ('database.php');

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$event_id = value($_POST['event_id']);

$sql = "SELECT COUNT(id) AS id FROM images WHERE event_id=$event_id";

$result = mysqli_query($conn, $sql);

$array = array();

echo mysqli_fetch_assoc($result)['id'];

mysqli_close($conn);
?>