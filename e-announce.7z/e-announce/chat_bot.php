<?php
require_once 'vendor/autoload.php';
use Stichoza\GoogleTranslate\GoogleTranslate;
include ('database.php');
if (!$conn)
	die("Connection Failed: " . mysqli_connect_error());

$uid = urlencode($_GET['uid']); // For brainshop
$user_id = $_GET['uid'];
$message = $_GET['msg']; // For datebase record
$tr = new GoogleTranslate('en');
$tr_msg = $tr->translate($_GET['msg']); // Translated message
$bot_lang = $tr->getLastDetectedSource(); // Language of bot response
$tr_msg_lc = strtolower($tr_msg); // For preset response
$msg = urlencode($tr_msg); // For brainshop
$url = "http://api.brainshop.ai/get?bid=169252&key=QE7YjbeCCNJPjD2e&uid=$uid&msg=$msg";

if (strpos($tr_msg_lc, 'event') && strpos($tr_msg_lc, 'today')) {
	$bot = getEvents('today');
	insertAndResponse($user_id, $message, $bot);
}
else if (strpos($tr_msg_lc, 'event') && strpos($tr_msg_lc, 'tomorrow')) {
	$bot = getEvents('tomorrow');
	insertAndResponse($user_id, $message, $bot);
}
else if (strpos($tr_msg_lc, 'all') && strpos($tr_msg_lc, 'event')) {
	$bot = getEvents('all');
	insertAndResponse($user_id, $message, $bot);
}
// If not catched above, use chatbot.
else {
	$response = file_get_contents($url);
	$bot = json_decode($response)->cnt;
	if ($bot_lang === 'tl') {
		$tr = new GoogleTranslate($bot_lang);
		$bot = $tr->translate($bot);
	}
	else if ($bot_lang === null) {
		$tr = new GoogleTranslate('ceb');
		$bot = $tr->translate($bot);
	}
	else {
		// The response will not be translated
	}
	insertAndResponse($user_id, $message, $bot);
}

mysqli_close($conn);

function getEvents($param) {
	global $conn;
	$date = date('Y-m-d');
	if ($param === 'all') {
		$sql = "SELECT * FROM events";
	}
	else if ($param === 'today') {
		$sql = "SELECT * FROM events WHERE date = CURDATE()";
	}
	else if ($param === 'tomorrow') {
		$sql = "SELECT * FROM events WHERE date = CURDATE() + INTERVAL 1 DAY";
	}
	
	$result = mysqli_query($conn, $sql);
	$str_response = "";
	if (mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
			$str_response .= $row['event_name'].'\n';
			$str_response .= $row['date'].'\n';
			$str_response .= $row['time'].'\n';
			$str_response .= $row['description'].'\n\n';
		}
	}
	else {
		$str_response = 'There are no event today';
	}
	return $str_response;
}

function insertAndResponse($user_id, $message, $bot) {
	global $conn;
	$message = value(clean($message));
	$bot = value(clean($bot));
	$sql = "INSERT INTO messages(user_id, message, bot) VALUES($user_id, $message, $bot)";
	mysqli_query($conn, $sql);
	$id = $conn->insert_id;
	$sql = "SELECT bot FROM messages WHERE id = $id";
	$result = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($result)['bot'];
	echo '{"cnt":"'.$result.'"}';
}
?>