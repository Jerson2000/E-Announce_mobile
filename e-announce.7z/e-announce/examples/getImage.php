<?php
$output_image = '39.jpg';
$image = imagecreatefrompng('../image/39.jpg');
imagejpeg($image, $output_image, 10);
echo '<img src="'.$output_image.'"/>';

?>
