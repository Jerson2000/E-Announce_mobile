<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $image = $_POST['image'];
    $name = $_POST['name'];
    $path = "image/$name.jpg";
    file_put_contents($path,base64_decode($image));
}
?>