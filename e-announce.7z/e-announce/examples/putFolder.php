<?php
include ('database.php');

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$sql = "SELECT id, image FROM images";

$result = mysqli_query($conn, $sql);

$array = array();

while ($row = mysqli_fetch_assoc($result)) {
    $id = $row['id'];
    $path = "image/$id.jpg";
    file_put_contents($path,base64_decode($row['image']));
}
echo json_encode($array);

mysqli_close($conn);
?>