<?php
require_once 'vendor/autoload.php';
use Stichoza\GoogleTranslate\GoogleTranslate;
include ('database.php');
if (!$conn)
	die("Connection Failed: " . mysqli_connect_error());

$uid = urlencode($_GET['user_id']); // For brainshop
$user_id = $_GET['user_id'];
$message = $_GET['message']; // For datebase record
$tr = new GoogleTranslate('en');
$tr_msg = $tr->translate($_GET['message']); // Translated message
$bot_lang = $tr->getLastDetectedSource(); // Language of bot response
$tr_msg_lc = strtolower($tr_msg); // For preset response
$msg = urlencode($tr_msg); // For brainshop
$url = "http://api.brainshop.ai/get?bid=169252&key=QE7YjbeCCNJPjD2e&uid=$uid&msg=$msg";

if (strpos($tr_msg_lc, 'event') && strpos($tr_msg_lc, 'today')) {
	$bot = getEvents('today');
	$bot = translatedBotResponse($bot);
	insertAndResponse($user_id, $message, $bot);
}
else if (strpos($tr_msg_lc, 'event') && strpos($tr_msg_lc, 'tomorrow')) {
	$bot = getEvents('tomorrow');
	$bot = translatedBotResponse($bot);
	insertAndResponse($user_id, $message, $bot);
}
else if (strpos($tr_msg_lc, 'all') && strpos($tr_msg_lc, 'event')) {
	$bot = getEvents('all');
	$bot = translatedBotResponse($bot);
	insertAndResponse($user_id, $message, $bot);
}
// If not catched above, use chatbot.
else {
	$response = file_get_contents($url);
	$bot = json_decode($response)->cnt;
	$bot = translatedBotResponse($bot);
	insertAndResponse($user_id, $message, $bot);
}

mysqli_close($conn);

function getEvents($param) {
	global $conn;
	$date = date('Y-m-d');
	if ($param === 'all') {
		$sql = "SELECT * FROM events";
	}
	else if ($param === 'today') {
		$sql = "SELECT * FROM events WHERE date = CURDATE()";
	}
	else if ($param === 'tomorrow') {
		$sql = "SELECT * FROM events WHERE date = CURDATE() + INTERVAL 1 DAY";
	}
	
	$result = mysqli_query($conn, $sql);
	$str_response = "";
	if (mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
			$str_response .= $row['event_name'].'\n';
			$str_response .= $row['date'].'\n';
			$str_response .= $row['time'].'\n';
			$str_response .= $row['description'].'\n\n';
		}
	}
	else {
        if ($param === 'all')
		    $str_response = 'There are no events';
        else if ($param === 'today')
            $str_response = 'There are no events today';
        else if ($param === 'tomorrow')
            $str_response = 'There are no events tommorrow';
	}
	return $str_response;
}

function insertAndResponse($user_id, $message, $bot) {
	global $conn;
	$message = value(clean($message));
	$bot = value(clean($bot));
	$sql = "INSERT INTO messages(user_id, message, bot) VALUES($user_id, $message, $bot)";
	mysqli_query($conn, $sql);
	$id = $conn->insert_id;
	$sql = "SELECT bot FROM messages WHERE id = $id";
	$result = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($result)['bot'];
	echo $result;
}

// The language type of the user is stored in $bot_lang
// So that the reponse of the bot is same to language of user
function translatedBotResponse($reponse) {
	global $bot_lang;
	if ($bot_lang !== null) {
		$tr = new GoogleTranslate($bot_lang);
		$tr = $tr->translate($reponse);
		return $tr;
	}
	if ($bot_lang === null) {
		$tr = new GoogleTranslate('ceb');
		$tr = $tr->translate($reponse);
		return $tr;
	}
	return $reponse;
}
?>