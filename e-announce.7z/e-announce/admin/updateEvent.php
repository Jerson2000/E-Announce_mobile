<?php
include ('../database.php');
if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$id = $_POST['id'];
$event_name = value(clean($_POST['event_name']));
$date = value(clean($_POST['date']));
$time = value(clean($_POST['time']));
$description = value(clean($_POST['description']));

$sql = "UPDATE events 
        SET event_name = $event_name,
        date = $date,
        time = $time,
        description = $description 
        WHERE id = $id";
$result = mysqli_query($conn, $sql);

$array = array();
$sql = strtok($sql, ' ');

if ($sql === 'INSERT' || $sql === 'UPDATE' || $sql === 'DELETE') {
    echo '[{result: Success}]';
}
else if ($sql === 'SELECT') {
    while ($row = mysqli_fetch_assoc($result)) {
        $temp = array();
        foreach ($row as $key => $value) {
            $temp[$key] = $value;
        }
        array_push($array, $temp);
    }
    echo json_encode($array);
}

mysqli_close($conn);
?>