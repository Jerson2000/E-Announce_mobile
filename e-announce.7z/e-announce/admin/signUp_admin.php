<?php
include ('../database.php');

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$name = value($_POST['name']);
$email = value($_POST['email']);
$password = value($_POST['password']);
$number = value($_POST['number']);
$purok = value($_POST['address']);

$sql = "INSERT INTO admins(name, email, password, number, purok) 
        VALUES ($name, $email, $password, $number, $purok)";

$result = mysqli_query($conn, $sql);

$array = array();
$sql = strtok($sql, ' ');

if ($sql === 'INSERT' || $sql === 'UPDATE' || $sql === 'DELETE') {
    echo '[{result: Success}]';
}
else if ($sql === 'SELECT') {
    while ($row = mysqli_fetch_assoc($result)) {
        $temp = array();
        foreach ($row as $key => $value) {
            $temp[$key] = $value;
        }
        array_push($array, $temp);
    }
    echo json_encode($array);
}

mysqli_close($conn);
?>