<?php
include ('../database.php');
if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$event_name = value(clean($_POST['event_name']));
$date = value(clean($_POST['date']));
$time = value(clean($_POST['time']));
$description = value(clean($_POST['description']));

$sql = "INSERT INTO events (event_name, date, time, description)
        VALUES ($event_name, $date, $time, $description)";
$result = mysqli_query($conn, $sql);

$array = array();
$sql = strtok($sql, ' ');

if ($sql === 'INSERT' || $sql === 'UPDATE' || $sql === 'DELETE') {
    echo '[{result: Success}]';
}
else if ($sql === 'SELECT') {
    while ($row = mysqli_fetch_assoc($result)) {
        $temp = array();
        foreach ($row as $key => $value) {
            $temp[$key] = $value;
        }
        array_push($array, $temp);
    }
    echo json_encode($array);
}

mysqli_close($conn);
?>