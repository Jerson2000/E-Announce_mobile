<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'e-announce';
$conn = mysqli_connect($host, $username, $password, $database);

function value($string) {
    return "'".$string."'";
}

function clean($string) {
    $string = str_replace("'", "\'", $string);
    $string = str_replace('"', '\"', $string);
    return $string;
}

function removeSpecialCharacters($string) {
    $string = str_replace('?', '', $string);
    $string = str_replace('!', '', $string);
    $string = str_replace(',', '', $string);
    $string = str_replace('.', '', $string);
    $string = str_replace('"', '', $string);
    $string = str_replace("'", '', $string);
    return $string;
}
?>