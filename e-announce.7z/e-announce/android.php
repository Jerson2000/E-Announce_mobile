<?php
include ('database.php');

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$query = $_POST['query'];
$sql = $query;
$result = mysqli_query($conn, $sql);
$array = array();
$query = strtok($query, ' ');

if ($query === 'INSERT' || $query === 'UPDATE' || $query === 'DELETE') {
	echo '[{result: Success}]';
}
else if ($query === 'SELECT') {
	while ($row = mysqli_fetch_assoc($result)) {
		$temp = array();
		foreach ($row as $key => $value) {
			$temp[$key] = $value;
		}
		array_push($array, $temp);
	}
	echo json_encode($array);
}



mysqli_close($conn);
?>