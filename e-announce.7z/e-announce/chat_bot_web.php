<?php
include ('database.php');
if (!$conn)
	die("Connection Failed: " . mysqli_connect_error());

$uid = urlencode($_GET['uid']);
$msg = urlencode($_GET['msg']);
$url = "http://api.brainshop.ai/get?bid=169252&key=QE7YjbeCCNJPjD2e&uid=$uid&msg=$msg";
$response = file_get_contents($url);
$bot = value(clean(json_decode($response)->cnt));
$user_id = value($_GET['uid']);
$message = value(clean($_GET['msg']));

$sql = "SELECT * FROM messages WHERE $keyword = $message";
if ($message == $message) {
	
}
else {
	$sql = "INSERT INTO messages(user_id, message, bot) VALUES($user_id, $message, $bot)";
	mysqli_query($conn, $sql);
	$id = $conn->insert_id;
	$sql = "SELECT bot FROM messages WHERE id = $id";
	$result = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($result)['bot'];
	echo "callback('$result')";
}

mysqli_close($conn);
?>