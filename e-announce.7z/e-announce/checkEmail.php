<?php
include ('database.php');

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$email = value($_POST['email']);

$sql = "SELECT email 
        FROM users 
        WHERE email=$email";

$result = mysqli_query($conn, $sql);

$array = array();
$sql = strtok($sql, ' ');

if ($sql === 'INSERT' || $sql === 'UPDATE' || $sql === 'DELETE') {
    echo '[{result: Success}]';
}
else if ($sql === 'SELECT') {
    while ($row = mysqli_fetch_assoc($result)) {
        $temp = array();
        foreach ($row as $key => $value) {
            $temp[$key] = $value;
        }
        array_push($array, $temp);
    }
    echo json_encode($array);
}

mysqli_close($conn);
?>