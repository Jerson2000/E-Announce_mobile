<?php
include ('database.php');

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}

$event_id = value($_POST['event_id']);

$sql = "SELECT * FROM images WHERE event_id=$event_id";

$result = mysqli_query($conn, $sql);

$array = array();

while($row = mysqli_fetch_assoc($result)){
    $temp = array();
    $image = file_get_contents($row['image']);
    $image = base64_encode($image);
    $temp['image'] = $image;
    $temp['id'] = $row['id'];
    $temp['event_id'] = $row['event_id'];
    $temp['created_at'] = $row['created_at'];
    array_push($array, $temp);
}

echo json_encode($array);

mysqli_close($conn);
?>